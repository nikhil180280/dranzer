
import sqlite3, math, json
DB_PATH = "../data/pois.db"

def haversine(lat1, lon1, lat2, lon2):
    R=6371
    phi1,phi2=math.radians(lat1),math.radians(lat2)
    dphi=math.radians(lat2-lat1); dl=math.radians(lon2-lon1)
    a=math.sin(dphi/2)**2 + math.cos(phi1)*math.cos(phi2)*math.sin(dl/2)**2
    return 2*R*math.asin(math.sqrt(a))

def load_pois(db_path=DB_PATH):
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    cur.execute("SELECT id,name,lat,lon,category,rating,hidden_factor,avg_visit_hours,avg_cost,micro_reviews FROM poi")
    rows = cur.fetchall()
    conn.close()
    pois=[]
    for r in rows:
        pois.append({
            'id': r[0], 'name': r[1], 'lat': r[2], 'lon': r[3],
            'category': r[4], 'rating': r[5],
            'hidden_factor': r[6], 'avg_visit_hours': r[7],
            'avg_cost': r[8], 'micro_reviews': r[9]
        })
    return pois

def score_poi(poi, interests, user_loc):
    match = 1.0 if poi['category'] in interests else 0.3
    rating = poi['rating'] / 5.0
    hidden = poi['hidden_factor']
    dist_km = haversine(user_loc[0], user_loc[1], poi['lat'], poi['lon'])
    dist_penalty = 1 / (1 + dist_km)
    # weighted combination emphasizes hidden gems and interest match
    score = 0.4*match + 0.3*rating + 0.2*hidden + 0.1*dist_penalty
    return score

def plan_trip(start_loc, days=2, interests=['culture','food'], hours_per_day=8):
    pois = load_pois()
    remaining = pois.copy()
    itinerary = []
    cur_loc = start_loc
    for d in range(days):
        day_hours = hours_per_day
        day_plan = []
        remaining.sort(key=lambda p: score_poi(p, interests, cur_loc), reverse=True)
        for p in remaining[:40]:
            travel_km = haversine(cur_loc[0],cur_loc[1],p['lat'],p['lon'])
            travel_time = max(0.05, travel_km / 30.0)
            visit = p.get('avg_visit_hours') or 1.0
            if travel_time + visit <= day_hours:
                day_plan.append({
                    'id': p['id'], 'name': p['name'], 'category': p['category'],
                    'lat': p['lat'], 'lon': p['lon'],
                    'travel_km': round(travel_km,2), 'visit_hours': visit,
                    'est_cost': p['avg_cost'], 'micro_reviews': p['micro_reviews']
                })
                day_hours -= (travel_time + visit)
                cur_loc = (p['lat'], p['lon'])
        used_ids = set([x['id'] for x in day_plan])
        remaining = [x for x in remaining if x['id'] not in used_ids]
        itinerary.append(day_plan)
    return itinerary

if __name__ == "__main__":
    # demo
    start = (17.3850,78.4867)
    it = plan_trip(start, days=2, interests=['food','culture'], hours_per_day=8)
    print(json.dumps(it, indent=2))
