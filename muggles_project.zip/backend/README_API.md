Run `python app.py` to start the API. GET /plan?days=2&interests=food,culture&lat=17.3850&lon=78.4867
