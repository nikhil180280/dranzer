
from flask import Flask, request, jsonify
from flask_cors import CORS
from itinerary import plan_trip
app = Flask(__name__)
CORS(app)

@app.route("/plan")
def plan():
    try:
        days = int(request.args.get('days',2))
        interests = request.args.get('interests','culture,food').split(',')
        lat = float(request.args.get('lat',17.3850))
        lon = float(request.args.get('lon',78.4867))
        hours = float(request.args.get('hours',8))
        it = plan_trip((lat,lon), days=days, interests=interests, hours_per_day=hours)
        return jsonify({"status":"ok","itinerary": it})
    except Exception as e:
        return jsonify({"status":"error","message":str(e)}),400

if __name__ == "__main__":
    app.run(debug=True)
