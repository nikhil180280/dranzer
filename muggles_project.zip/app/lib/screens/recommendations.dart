
import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'mapview.dart';

class RecoScreen extends StatefulWidget {
  @override
  _RecoScreenState createState() => _RecoScreenState();
}

class _RecoScreenState extends State<RecoScreen> {
  List items = [];
  bool loading = false;

  void fetchRecommendations() async {
    setState(() { loading = true; });
    try {
      final resp = await http.get(Uri.parse('http://10.0.2.2:5000/plan?days=2&interests=food,culture&lat=17.3850&lon=78.4867'));
      final data = json.decode(resp.body);
      setState(() {
        items = data['itinerary'].expand((d) => d).toList();
        loading = false;
      });
    } catch (e) {
      print(e);
      setState(() { loading = false; });
    }
  }

  @override
  void initState() {
    super.initState();
    fetchRecommendations();
  }

  @override
  Widget build(BuildContext ctx) {
    return Scaffold(
      appBar: AppBar(title: Text('Recommendations')),
      body: loading ? Center(child: CircularProgressIndicator()) :
      Column(children: [
        Expanded(
          child: ListView.builder(
            padding: EdgeInsets.all(12),
            itemCount: items.length,
            itemBuilder: (c,i){
              final it = items[i];
              return Card(
                child: ListTile(
                  title: Text(it['name']),
                  subtitle: Text('${it['category']} • ${it['visit_hours']} hrs • ${it['est_cost']}'),
                  onTap: () {
                    Navigator.push(ctx, MaterialPageRoute(builder: (_) => MapView(initialLat: it['lat'], initialLon: it['lon'])));
                  },
                ),
              );
            }
          ),
        ),
      ]),
    );
  }
}
