
import 'package:flutter/material.dart';
import 'recommendations.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext c) {
    return Scaffold(
      appBar: AppBar(title: Text('Muggles Tourism')),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(children: [
          Image.asset('assets/images/logo.png', width:120),
          SizedBox(height:12),
          Text('Discover hidden local experiences', style: TextStyle(fontSize:18)),
          SizedBox(height:20),
          ElevatedButton(
            child: Text('Generate recommendations (Demo)'),
            onPressed: () {
              Navigator.push(c, MaterialPageRoute(builder: (_) => RecoScreen()));
            },
          ),
        ]),
      ),
    );
  }
}
