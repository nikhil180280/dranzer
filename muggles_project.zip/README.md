
# Muggles Tourism — AI-Powered Local Experience Discovery (Prototype)

This repository contains a hackathon-ready prototype for **Muggles Tourism**, an AI-assisted, offline-capable platform
that discovers local, offbeat experiences and creates personalized itineraries.

## What's included
- `backend/` — Python itinerary generator + Flask API
- `data/pois.db` — SQLite database with 60 sample POIs (demo region)
- `app/` — Flutter app skeleton (screens, DB loader placeholders, map integration code samples)
- `docs/` — instructions for offline MBTiles, demo script, and setup guide
- `assets/` — logo and splash placeholder images

## Quick start (backend)
1. Create a virtual environment:
   ```bash
   python3 -m venv venv
   source venv/bin/activate
   ```

2. Install requirements:
   ```bash
   pip install -r backend/requirements.txt
   ```

3. Run the Flask API (serves itinerary JSON):
   ```bash
   python backend/app.py
   ```

4. Open `http://localhost:5000/plan?days=2&interests=food,culture&lat=17.3850&lon=78.4867`

## Quick start (Flutter)
- Open `app/` in Flutter. The Flutter project contains skeleton code showing how to call the backend
  and render recommendations and a map placeholder using `flutter_map`.
- The app is configured to fetch recommendations from the local Flask API for demo purposes.

## Notes on offline maps
See `docs/offline_maps.md` for step-by-step instructions to create MBTiles and use them with the Flutter app.

## Structure
- backend/
  - app.py           # Flask app that returns itinerary JSON
  - itinerary.py     # rule-based itinerary planner + recommender logic
  - requirements.txt
- data/
  - pois.db          # sample POI database (60 entries)
- app/
  - lib/
    - main.dart
    - screens/...
  - pubspec.yaml
- docs/
  - offline_maps.md
  - demo_script.md

