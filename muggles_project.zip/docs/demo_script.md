
# Demo Script (90s)

1. Start backend: python backend/app.py
2. Open Flutter app in emulator: flutter run
3. On Home, tap 'Generate recommendations' - app calls local API and displays itinerary.
4. Tap any POI to open Map view centered on that POI.
5. Mention offline capability, MBTiles, and privacy (all data local).
