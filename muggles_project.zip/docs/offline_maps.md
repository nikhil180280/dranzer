
# Offline Maps (MBTiles) — Quick Guide

1. Export OSM extract for your demo area (small bbox). Use https://extract.bbbike.org/ or Geofabrik.
2. Use tilemaker or MapTiler to create MBTiles with zoom levels 10-16 to keep size small.
3. Place the MBTiles file into the Flutter app assets and use flutter_map + flutter_map_mbtiles (or MapLibre plugin) to load tiles from local storage.
4. For development/demo, the app uses online OSM tiles. Replace TileLayer options with MBTiles provider for offline.

Commands (example using tilemaker):
- Install tilemaker and its dependencies.
- Run: tilemaker your_region.osm.pbf

MapTiler desktop can export MBTiles via GUI if needed.
